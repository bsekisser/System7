# System 7.1 Reimplementation – Hot Mess 4

A clean-room reimplementation of classic Macintosh System 7.1 for modern hardware.

## Release: Hot Mess 4

This release focuses on critical window system fixes and extensive security hardening:

- **Window coordinate system fixes** – Fixed critical bugs in window resize and drag operations that caused content to render incorrectly. The portRect now correctly uses LOCAL coordinates (0,0,w,h) throughout the system.
- **VFS boot volume mounting** – Fixed volume mounting issues by reducing boot volume size from 4MB to 1MB, ensuring the hard drive icon appears on the desktop.
- **Security hardening** – 300+ security fixes including buffer overflow protection, integer overflow validation, division-by-zero checks, and bounds checking throughout the codebase.
- **Build system improvements** – Fixed C89 compliance issues, resolved duplicate symbol conflicts, and improved SegmentLoader build process.

### What's Included

- `system71.iso` – Bootable ISO image with the latest System 7.1 reimplementation
- `test_disk.img` – 100 MB HFS-formatted virtual disk with sample files
- `run.sh` – Quick launch script for QEMU on Linux hosts

### Requirements

- QEMU (tested with `qemu-system-i386`)
- 256 MB RAM allocation (minimum)
- Linux host (Ubuntu/Debian-based systems recommended)

### Quick Start

```bash
chmod +x run.sh
./run.sh
```

### Manual Launch

If you prefer to run QEMU manually:

```bash
qemu-system-i386 \
    -cdrom system71.iso \
    -drive file=test_disk.img,format=raw,if=ide \
    -m 256 \
    -vga std \
    -serial stdio
```

### Usage Tips

- **Mouse capture**: Click inside the QEMU window to capture the mouse
- **Release mouse**: Press `Ctrl+Alt+G`
- **Debug output**: Serial debug messages appear in the terminal
- **Shut down**: Apple Menu → Shut Down

### Highlights in Hot Mess 4

- **Fixed window resize rendering** – Windows now redraw correctly after resizing operations
- **Fixed window drag rendering** – Content appears correctly positioned after dragging windows
- **Working hard drive icon** – The "Macintosh HD" icon now appears on the Finder desktop
- **Security improvements** – Extensive validation and bounds checking prevents crashes and exploits
- **Fixed Delay() hang** – System no longer freezes when TickCount doesn't advance

### Known Issues

This is still an early development snapshot:
- ARM64 port exists but is incomplete/untested
- Many menu items remain placeholders
- Graphics stay in classic VGA mode
- Some features remain work-in-progress

### Development Notes

Source code: https://github.com/Kelsidavis/System7
Git tag: `hot-mess-4`
Commit: `4a68085`

### Technical Details

The main fixes in this release address coordinate system bugs in the Window Manager:

1. **portRect coordinate system** – Changed from preserving offsets to explicit LOCAL coordinates (0,0,w,h)
2. **Region recalculation** – Removed redundant Platform_CalculateWindowRegions() call that was overwriting correct values
3. **Global Framebuffer approach** – Consistent coordinate system: portRect=LOCAL, portBits.bounds=GLOBAL, strucRgn/contRgn=GLOBAL

These bugs caused window content to render incorrectly after resize operations, similar to the drag bug fixed in an earlier commit.

### License

This project is a clean-room reimplementation created without access to Apple's original source code. Use at your own risk.
