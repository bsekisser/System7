#!/bin/bash
# System 7.1 Reimplementation - Hot Mess 4
# Quick launch script for QEMU (Linux)

set -e

echo "Starting System 7.1 Reimplementation (Hot Mess 4)..."
echo "Press Ctrl+Alt+G to release mouse capture"
echo "Serial debug output will appear in this terminal"
echo ""

qemu-system-i386 \
    -cdrom system71.iso \
    -drive file=test_disk.img,format=raw,if=ide \
    -m 256 \
    -vga std \
    -serial stdio
